import { useState, useEffect } from 'react';
import { Plus, Edit, Save, X } from 'lucide-react';

const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

export default function Tasks({ user }) {
  const [tasks, setTasks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [apartments, setApartments] = useState([]);
  const [users, setUsers] = useState([]);
  const [contractors, setContractors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category_id: '',
    apartment_id: '',
    assigned_to: '',
    contractor_id: '',
    status: 'pending',
    priority: 'medium',
    task_type: 'reactive',
    due_date: '',
    estimated_cost: '',
    actual_cost: '',
    remarks: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('lmb_token');
      const headers = { 'Authorization': `Bearer ${token}` };

      const [tasksRes, categoriesRes, apartmentsRes, usersRes, contractorsRes] = await Promise.all([
        fetch(`${API_BASE}/tasks`, { headers }),
        fetch(`${API_BASE}/categories`, { headers }),
        fetch(`${API_BASE}/apartments`, { headers }),
        fetch(`${API_BASE}/users`, { headers }),
        fetch(`${API_BASE}/contractors`, { headers }),
      ]);

      setTasks(await tasksRes.json());
      setCategories(await categoriesRes.json());
      setApartments(await apartmentsRes.json());
      if (usersRes.ok) setUsers(await usersRes.json());
      setContractors(await contractorsRes.json());
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('lmb_token');
    const url = editingTask ? `${API_BASE}/tasks/${editingTask.id}` : `${API_BASE}/tasks`;
    const method = editingTask ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await fetchData();
        resetForm();
      }
    } catch (error) {
      console.error('Error saving task:', error);
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingTask(null);
    setFormData({
      title: '',
      description: '',
      category_id: '',
      apartment_id: '',
      assigned_to: '',
      contractor_id: '',
      status: 'pending',
      priority: 'medium',
      task_type: 'reactive',
      due_date: '',
      estimated_cost: '',
      actual_cost: '',
      remarks: '',
    });
  };

  const handleEdit = (task) => {
    setEditingTask(task);
    setFormData({
      title: task.title || '',
      description: task.description || '',
      category_id: task.category_id || '',
      apartment_id: task.apartment_id || '',
      assigned_to: task.assigned_to || '',
      contractor_id: task.contractor_id || '',
      status: task.status || 'pending',
      priority: task.priority || 'medium',
      task_type: task.task_type || 'reactive',
      due_date: task.due_date || '',
      estimated_cost: task.estimated_cost || '',
      actual_cost: task.actual_cost || '',
      remarks: task.remarks || '',
    });
    setShowForm(true);
  };

  if (loading) {
    return <div className="p-6">Loading tasks...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Maintenance Tasks</h1>
        <button
          onClick={() => setShowForm(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          New Task
        </button>
      </div>

      {/* Task Form */}
      {showForm && (
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">
              {editingTask ? 'Edit Task' : 'Create New Task'}
            </h2>
            <button onClick={resetForm} className="text-gray-500 hover:text-gray-700">
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="label">Title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="input"
                required
              />
            </div>

            <div className="md:col-span-2">
              <label className="label">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="input"
                rows={3}
              />
            </div>

            <div>
              <label className="label">Category</label>
              <select
                value={formData.category_id}
                onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                className="input"
              >
                <option value="">Select category</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Apartment/Area</label>
              <select
                value={formData.apartment_id}
                onChange={(e) => setFormData({ ...formData, apartment_id: e.target.value })}
                className="input"
              >
                <option value="">Select location</option>
                {apartments.map(apt => (
                  <option key={apt.id} value={apt.id}>
                    {apt.unit_number} - {apt.area_type}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Assign To</label>
              <select
                value={formData.assigned_to}
                onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                className="input"
              >
                <option value="">Select staff</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Contractor</label>
              <select
                value={formData.contractor_id}
                onChange={(e) => setFormData({ ...formData, contractor_id: e.target.value })}
                className="input"
              >
                <option value="">Select contractor</option>
                {contractors.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="input"
              >
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>

            <div>
              <label className="label">Priority</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                className="input"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>

            <div>
              <label className="label">Type</label>
              <select
                value={formData.task_type}
                onChange={(e) => setFormData({ ...formData, task_type: e.target.value })}
                className="input"
              >
                <option value="reactive">Reactive</option>
                <option value="preventive">Preventive</option>
              </select>
            </div>

            <div>
              <label className="label">Due Date</label>
              <input
                type="date"
                value={formData.due_date}
                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                className="input"
              />
            </div>

            <div>
              <label className="label">Estimated Cost ($)</label>
              <input
                type="number"
                step="0.01"
                value={formData.estimated_cost}
                onChange={(e) => setFormData({ ...formData, estimated_cost: e.target.value })}
                className="input"
              />
            </div>

            <div>
              <label className="label">Actual Cost ($)</label>
              <input
                type="number"
                step="0.01"
                value={formData.actual_cost}
                onChange={(e) => setFormData({ ...formData, actual_cost: e.target.value })}
                className="input"
              />
            </div>

            <div className="md:col-span-2">
              <label className="label">Remarks</label>
              <textarea
                value={formData.remarks}
                onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                className="input"
                rows={2}
              />
            </div>

            <div className="md:col-span-2 flex gap-3">
              <button type="submit" className="btn-primary flex items-center gap-2">
                <Save className="w-5 h-5" />
                {editingTask ? 'Update Task' : 'Create Task'}
              </button>
              <button type="button" onClick={resetForm} className="btn-secondary">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tasks List */}
      <div className="card">
        <h2 className="text-xl font-bold mb-4">All Tasks ({tasks.length})</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Title</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Location</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Priority</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Due Date</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Cost</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {tasks.map(task => (
                <tr key={task.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm">{task.title}</td>
                  <td className="px-4 py-3 text-sm">{task.apartment_unit || 'N/A'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      task.status === 'completed' ? 'bg-green-100 text-green-700' :
                      task.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {task.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      task.priority === 'urgent' ? 'bg-red-100 text-red-700' :
                      task.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {task.priority}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm">{task.due_date || '-'}</td>
                  <td className="px-4 py-3 text-sm">
                    ${(task.actual_cost || task.estimated_cost || 0).toLocaleString('en-CA')}
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => handleEdit(task)}
                      className="text-primary-600 hover:text-primary-800"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
