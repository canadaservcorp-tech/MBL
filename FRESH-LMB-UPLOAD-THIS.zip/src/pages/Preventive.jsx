import { useState, useEffect } from 'react';
import { Plus, Calendar } from 'lucide-react';

const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

export default function Preventive({ user }) {
  const [schedules, setSchedules] = useState([]);
  const [categories, setCategories] = useState([]);
  const [apartments, setApartments] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category_id: '',
    apartment_id: '',
    frequency: 'monthly',
    next_due_date: '',
    assigned_to: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('lmb_token');
      const headers = { 'Authorization': `Bearer ${token}` };

      const [schedulesRes, categoriesRes, apartmentsRes, usersRes] = await Promise.all([
        fetch(`${API_BASE}/preventive`, { headers }),
        fetch(`${API_BASE}/categories`, { headers }),
        fetch(`${API_BASE}/apartments`, { headers }),
        fetch(`${API_BASE}/users`, { headers }),
      ]);

      setSchedules(await schedulesRes.json());
      setCategories(await categoriesRes.json());
      setApartments(await apartmentsRes.json());
      if (usersRes.ok) setUsers(await usersRes.json());
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('lmb_token');

    try {
      const response = await fetch(`${API_BASE}/preventive`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await fetchData();
        resetForm();
      }
    } catch (error) {
      console.error('Error saving schedule:', error);
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setFormData({
      title: '',
      description: '',
      category_id: '',
      apartment_id: '',
      frequency: 'monthly',
      next_due_date: '',
      assigned_to: '',
    });
  };

  if (loading) {
    return <div className="p-6">Loading preventive schedules...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Preventive Maintenance</h1>
        {user.role === 'admin' && (
          <button
            onClick={() => setShowForm(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            New Schedule
          </button>
        )}
      </div>

      {/* Schedule Form */}
      {showForm && (
        <div className="card">
          <h2 className="text-xl font-bold mb-4">Create Preventive Schedule</h2>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="label">Title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="input"
                required
              />
            </div>

            <div className="md:col-span-2">
              <label className="label">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="input"
                rows={3}
              />
            </div>

            <div>
              <label className="label">Category</label>
              <select
                value={formData.category_id}
                onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                className="input"
              >
                <option value="">Select category</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Apartment/Area</label>
              <select
                value={formData.apartment_id}
                onChange={(e) => setFormData({ ...formData, apartment_id: e.target.value })}
                className="input"
              >
                <option value="">Select location</option>
                {apartments.map(apt => (
                  <option key={apt.id} value={apt.id}>
                    {apt.unit_number} - {apt.area_type}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Frequency *</label>
              <select
                value={formData.frequency}
                onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
                className="input"
                required
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>

            <div>
              <label className="label">Next Due Date *</label>
              <input
                type="date"
                value={formData.next_due_date}
                onChange={(e) => setFormData({ ...formData, next_due_date: e.target.value })}
                className="input"
                required
              />
            </div>

            <div>
              <label className="label">Assign To</label>
              <select
                value={formData.assigned_to}
                onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                className="input"
              >
                <option value="">Select staff</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2 flex gap-3">
              <button type="submit" className="btn-primary">
                Create Schedule
              </button>
              <button type="button" onClick={resetForm} className="btn-secondary">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Schedules List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {schedules.map(schedule => (
          <div key={schedule.id} className="card">
            <div className="flex items-start justify-between mb-3">
              <h3 className="font-bold text-lg text-gray-900">{schedule.title}</h3>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                schedule.frequency === 'daily' ? 'bg-purple-100 text-purple-700' :
                schedule.frequency === 'weekly' ? 'bg-blue-100 text-blue-700' :
                schedule.frequency === 'monthly' ? 'bg-green-100 text-green-700' :
                schedule.frequency === 'quarterly' ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>
                {schedule.frequency}
              </span>
            </div>
            
            {schedule.description && (
              <p className="text-sm text-gray-600 mb-3">{schedule.description}</p>
            )}
            
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-gray-700">
                <Calendar className="w-4 h-4" />
                <span>Next: {schedule.next_due_date}</span>
              </div>
              {schedule.apartment_unit && (
                <div className="text-gray-600">Location: {schedule.apartment_unit}</div>
              )}
              {schedule.assigned_to_name && (
                <div className="text-gray-600">Assigned: {schedule.assigned_to_name}</div>
              )}
            </div>
          </div>
        ))}
      </div>

      {schedules.length === 0 && !showForm && (
        <div className="card text-center py-12">
          <Calendar className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-600">No preventive maintenance schedules yet</p>
        </div>
      )}
    </div>
  );
}
