import { useState, useEffect } from 'react';
import { Building2, Home, Wrench } from 'lucide-react';

const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

export default function Apartments() {
  const [apartments, setApartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchApartments();
  }, []);

  const fetchApartments = async () => {
    try {
      const token = localStorage.getItem('lmb_token');
      const response = await fetch(`${API_BASE}/apartments`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      setApartments(await response.json());
    } catch (error) {
      console.error('Error fetching apartments:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredApartments = apartments.filter(apt => {
    if (filter === 'all') return true;
    return apt.area_type === filter;
  });

  const groupedByFloor = filteredApartments.reduce((acc, apt) => {
    const floor = apt.floor ?? 'Other';
    if (!acc[floor]) acc[floor] = [];
    acc[floor].push(apt);
    return acc;
  }, {});

  const sortedFloors = Object.keys(groupedByFloor).sort((a, b) => {
    if (a === 'Other') return 1;
    if (b === 'Other') return -1;
    return parseInt(b) - parseInt(a);
  });

  if (loading) {
    return <div className="p-6">Loading apartments...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Apartments & Areas</h1>
        <p className="text-gray-600 mt-1">36 apartments and common areas at La Maison Benoit Labre</p>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 border-b border-gray-200">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 font-medium transition-colors ${
            filter === 'all'
              ? 'text-primary-600 border-b-2 border-primary-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          All ({apartments.length})
        </button>
        <button
          onClick={() => setFilter('apartment')}
          className={`px-4 py-2 font-medium transition-colors ${
            filter === 'apartment'
              ? 'text-primary-600 border-b-2 border-primary-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Apartments ({apartments.filter(a => a.area_type === 'apartment').length})
        </button>
        <button
          onClick={() => setFilter('common')}
          className={`px-4 py-2 font-medium transition-colors ${
            filter === 'common'
              ? 'text-primary-600 border-b-2 border-primary-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Common Areas ({apartments.filter(a => a.area_type === 'common').length})
        </button>
        <button
          onClick={() => setFilter('service')}
          className={`px-4 py-2 font-medium transition-colors ${
            filter === 'service'
              ? 'text-primary-600 border-b-2 border-primary-600'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Service Areas ({apartments.filter(a => a.area_type === 'service').length})
        </button>
      </div>

      {/* Apartments by Floor */}
      <div className="space-y-6">
        {sortedFloors.map(floor => (
          <div key={floor} className="card">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              {floor === 'Other' ? 'Other Areas' : `Floor ${floor}`}
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {groupedByFloor[floor].map(apt => (
                <div
                  key={apt.id}
                  className="border border-gray-200 rounded-lg p-4 hover:border-primary-500 transition-colors"
                >
                  <div className="flex items-center gap-2 mb-2">
                    {apt.area_type === 'apartment' && <Home className="w-5 h-5 text-primary-600" />}
                    {apt.area_type === 'common' && <Building2 className="w-5 h-5 text-blue-600" />}
                    {apt.area_type === 'service' && <Wrench className="w-5 h-5 text-green-600" />}
                    <span className="font-bold text-gray-900">{apt.unit_number}</span>
                  </div>
                  <div className="text-xs text-gray-600">{apt.description}</div>
                  <div className={`mt-2 inline-block px-2 py-1 rounded text-xs font-medium ${
                    apt.area_type === 'apartment' ? 'bg-primary-100 text-primary-700' :
                    apt.area_type === 'common' ? 'bg-blue-100 text-blue-700' :
                    'bg-green-100 text-green-700'
                  }`}>
                    {apt.area_type}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
