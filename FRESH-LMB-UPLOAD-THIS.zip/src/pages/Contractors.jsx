import { useState, useEffect } from 'react';
import { Plus, Edit, Save, X, Star } from 'lucide-react';

const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

export default function Contractors({ user }) {
  const [contractors, setContractors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingContractor, setEditingContractor] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    specialty: '',
    rating: '0',
    notes: '',
  });

  useEffect(() => {
    fetchContractors();
  }, []);

  const fetchContractors = async () => {
    try {
      const token = localStorage.getItem('lmb_token');
      const response = await fetch(`${API_BASE}/contractors`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      setContractors(await response.json());
    } catch (error) {
      console.error('Error fetching contractors:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('lmb_token');
    const url = editingContractor ? `${API_BASE}/contractors/${editingContractor.id}` : `${API_BASE}/contractors`;
    const method = editingContractor ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await fetchContractors();
        resetForm();
      }
    } catch (error) {
      console.error('Error saving contractor:', error);
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingContractor(null);
    setFormData({
      name: '',
      company: '',
      email: '',
      phone: '',
      specialty: '',
      rating: '0',
      notes: '',
    });
  };

  const handleEdit = (contractor) => {
    setEditingContractor(contractor);
    setFormData({
      name: contractor.name || '',
      company: contractor.company || '',
      email: contractor.email || '',
      phone: contractor.phone || '',
      specialty: contractor.specialty || '',
      rating: contractor.rating?.toString() || '0',
      notes: contractor.notes || '',
    });
    setShowForm(true);
  };

  if (loading) {
    return <div className="p-6">Loading contractors...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Contractors</h1>
        {user.role === 'admin' && (
          <button
            onClick={() => setShowForm(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Contractor
          </button>
        )}
      </div>

      {/* Contractor Form */}
      {showForm && user.role === 'admin' && (
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">
              {editingContractor ? 'Edit Contractor' : 'Add New Contractor'}
            </h2>
            <button onClick={resetForm} className="text-gray-500 hover:text-gray-700">
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Name *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="input"
                required
              />
            </div>

            <div>
              <label className="label">Company</label>
              <input
                type="text"
                value={formData.company}
                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                className="input"
              />
            </div>

            <div>
              <label className="label">Phone *</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="input"
                required
              />
            </div>

            <div>
              <label className="label">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="input"
              />
            </div>

            <div>
              <label className="label">Specialty</label>
              <input
                type="text"
                value={formData.specialty}
                onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
                className="input"
                placeholder="e.g. Plumbing, Electrical"
              />
            </div>

            <div>
              <label className="label">Rating (0-5)</label>
              <input
                type="number"
                min="0"
                max="5"
                step="0.1"
                value={formData.rating}
                onChange={(e) => setFormData({ ...formData, rating: e.target.value })}
                className="input"
              />
            </div>

            <div className="md:col-span-2">
              <label className="label">Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="input"
                rows={3}
              />
            </div>

            <div className="md:col-span-2 flex gap-3">
              <button type="submit" className="btn-primary flex items-center gap-2">
                <Save className="w-5 h-5" />
                {editingContractor ? 'Update Contractor' : 'Add Contractor'}
              </button>
              <button type="button" onClick={resetForm} className="btn-secondary">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Contractors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {contractors.map(contractor => (
          <div key={contractor.id} className="card">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-bold text-lg text-gray-900">{contractor.name}</h3>
                {contractor.company && (
                  <p className="text-sm text-gray-600">{contractor.company}</p>
                )}
              </div>
              {user.role === 'admin' && (
                <button
                  onClick={() => handleEdit(contractor)}
                  className="text-primary-600 hover:text-primary-800"
                >
                  <Edit className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  <Star className={`w-4 h-4 ${contractor.rating > 0 ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
                  <span className="ml-1 text-gray-700">{contractor.rating || 0}/5</span>
                </div>
              </div>
              
              <div className="text-gray-700">
                <strong>Phone:</strong> {contractor.phone}
              </div>
              
              {contractor.email && (
                <div className="text-gray-700">
                  <strong>Email:</strong> {contractor.email}
                </div>
              )}
              
              {contractor.specialty && (
                <div className="text-gray-700">
                  <strong>Specialty:</strong> {contractor.specialty}
                </div>
              )}
              
              {contractor.notes && (
                <div className="mt-3 p-3 bg-gray-50 rounded text-gray-600 text-xs">
                  {contractor.notes}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {contractors.length === 0 && !showForm && (
        <div className="card text-center py-12">
          <p className="text-gray-600">No contractors added yet</p>
        </div>
      )}
    </div>
  );
}
