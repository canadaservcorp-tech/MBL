# Deploy LMB Maintenance App to GitHub + Netlify

## Step-by-Step Guide

### 1. Extract the ZIP
```bash
unzip lmb-maintenance-app-complete.zip
cd lmb-maintenance-app
```

### 2. Initialize Git Repository
```bash
git init
git add .
git commit -m "Initial commit - LMB Maintenance App"
```

### 3. Create GitHub Repository
1. Go to https://github.com/new
2. Repository name: `lmb-maintenance-app`
3. Description: `La Maison Benoit Labre Maintenance Management System`
4. Make it **Private** (recommended for business app)
5. **DO NOT** initialize with README, .gitignore, or license
6. Click "Create repository"

### 4. Push to GitHub
```bash
# Replace YOUR-USERNAME with your GitHub username
git remote add origin https://github.com/YOUR-USERNAME/lmb-maintenance-app.git
git branch -M main
git push -u origin main
```

### 5. Deploy Frontend to Netlify

**Option A: Connect GitHub (Recommended)**
1. Go to https://app.netlify.com
2. Click "Add new site" → "Import from Git"
3. Choose GitHub
4. Select `lmb-maintenance-app` repository
5. Configure:
   - **Base directory:** leave empty
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Add environment variable:
   - Key: `VITE_API_BASE_URL`
   - Value: `http://localhost:4000/api` (change after backend deployed)
7. Click "Deploy site"

**Option B: Manual Deploy**
```bash
npm install
npm run build
# Then drag the 'dist' folder to netlify.com
```

### 6. Deploy Backend to Railway

1. Go to https://railway.app
2. Click "New Project"
3. Select "Deploy from GitHub repo"
4. Choose `lmb-maintenance-app`
5. Add environment variables:
   ```
   PORT=4000
   NODE_ENV=production
   JWT_SECRET=your-secure-32-char-secret-key
   BOOTSTRAP_KEY=your-bootstrap-secret
   CLIENT_URL=https://your-netlify-url.netlify.app
   DB_PATH=/data/maintenance.db
   ```
6. Add Volume:
   - Mount path: `/data`
   - Size: 1GB
7. Deploy!

### 7. Update Frontend with Backend URL

Once Railway gives you the backend URL:

1. In Netlify dashboard → Site settings → Environment variables
2. Update `VITE_API_BASE_URL` to: `https://your-railway-url.railway.app/api`
3. Trigger new deploy (or push new commit)

### 8. Bootstrap Admin User

```bash
curl -X POST https://your-railway-url.railway.app/api/auth/bootstrap \
  -H "Content-Type: application/json" \
  -H "x-bootstrap-key: your-bootstrap-secret" \
  -d '{
    "name": "Hicham",
    "email": "hicham@lmb.ca",
    "password": "YourSecurePassword123",
    "phone": "514-000-0000"
  }'
```

### 9. Test Your App!

Visit your Netlify URL and login!

---

## Quick Troubleshooting

**Build fails on Netlify?**
- Check `index.html` uses `./src/main.jsx` (relative path)
- Verify all dependencies in `package.json`

**Can't connect to backend?**
- Check `VITE_API_BASE_URL` in Netlify env vars
- Verify Railway backend is running
- Check CORS `CLIENT_URL` in Railway matches Netlify URL

**Database not persisting?**
- Ensure `/data` volume is mounted in Railway
- Check `DB_PATH=/data/maintenance.db`

---

## Your Live URLs

After deployment, you'll have:
- **Frontend:** `https://lmb-maintenance.netlify.app` (or custom domain)
- **Backend API:** `https://lmb-maintenance-production.up.railway.app`

---

## Estimated Costs

- **Railway:** $5-10/month (free trial available)
- **Netlify:** FREE (100GB bandwidth)
- **Total:** ~$5-10/month

---

## Done! 🎉

Your LMB Maintenance App is now live and accessible to your staff!
